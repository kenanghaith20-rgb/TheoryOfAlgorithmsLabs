from lab1.particlecalculator import ParticleCalculator

if __name__ == "__main__":
    calculator = ParticleCalculator()
    calculator.run()