CREATE TABLE IF NOT EXISTS public.adjective (word text NOT NULL);
CREATE TABLE IF NOT EXISTS public.noun (word text NOT NULL);
CREATE TABLE IF NOT EXISTS public.verb (word text NOT NULL);