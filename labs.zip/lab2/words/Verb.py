class Verb:
    def __init__(self, word):
        self.word = word

    def __str__(self):
        return self.word